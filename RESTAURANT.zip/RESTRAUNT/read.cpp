
#include <iostream>
#include <fstream>
#include <string>
#include <iterator>
#include <list>
#include <queue>
#include <vector>
#include <ctime>
#include <regex>

using namespace std;
int no_of_tables, no_of_servers, queqe_size;


class Time
{
    public:
    int hr; 
    int min;
    int sec;

    Time(int h, int m , int s)
    {
        hr=h;
        min=m;
        sec=s;
    }

     Time(int m)
    {
        hr=0;
        min=m;
        while(min>=60){
            min=m-60;
            hr=hr+1;
            
        }
        sec=0;
    }


    Time()
    { time_t now = time(0);
    tm *ltm = localtime(&now);
        hr=ltm->tm_hour;
        min=ltm->tm_min;
        sec=ltm->tm_sec;
        ;}

    Time operator + (Time const &obj) {
        Time t;
        t.sec = sec + obj.sec;
        if(t.sec>=60)
        t.min = min + obj.min +1;
        else
        t.min = min+ obj.min;
        t.sec%=60;
        if(t.min>=60)
        t.hr = hr + obj.hr +1;
        else
        t.hr = hr + obj.hr;
        t.min%=60;
        t.hr%=24;
         return t;
    }

     Time operator - (Time const &obj) {
        Time t;
        t.sec = sec - obj.sec;
        if(t.sec<0)
        t.min = min - obj.min -1;
        else
        t.min = min - obj.min;
        (t.sec)=(t.sec+ 60 )%60;
        if(t.min<0)
        t.hr = hr - obj.hr -1;
        else
        t.hr = hr - obj.hr;
        (t.min)=(t.min+ 60 )%60;
        t.hr%=24;
         return t;
    }
    bool operator ==(Time const &obj)
    {
        if(obj.hr!=hr)
        return false;
        else if(obj.min!=min)
        return false;
        else if (obj.sec!=sec)
        return false;
        else 
        return true;
    }

    bool operator >(Time const &obj)
    {
        Time t = *this - obj;
        if(t.hr<=0)
        return false;
        else
        return true;

    }

    bool operator <(Time const &obj)
    {
        Time t = *this - obj;
        if(t.hr>=0)
        return false;
        else
        return true;

    }



};

ostream& operator << (ostream& os, Time t)
{
    os << t.hr << ':' << t.min << ':' <<t.sec;
    return os;
}

class item
{
    public:
    int itemCode;
    string name;
    int cost;
    string type;
    Time prep_time;
    item(string n, int c, string t,int num,int ic)
    {   
        name=n;
        cost=c;
        type=t;
        prep_time= Time(num);
        itemCode=ic;

    }
    item()
    {
        
    }
    void display()
    {
        
        cout<<itemCode<<":"<<name<<":"<<cost<<":"<<type<<":"<<prep_time<<endl;
    } 
    
};

list<item> menu;

string generateRefNo(){
    static const char a[]="0123456789";
    string code;
    code.reserve(6);
    for(int i=0;i<6;i++){
        code+=a[rand()%9];
    }
    return code;
}

void read_menu()
{
    fstream f;
    f.open("menu.txt", ios::in );
    if(!f)
    {
        cout<<"File Not Found";
        return ;
    }
    list<item> l;
    string name;
    int cost;
    string type;
    int time;
    int ic;
    while (!f.eof()) 
    {    f>>ic;
        f>>name; 
         f>>cost;
         f>>type;
         f>>time;
        item i(name,cost,type, time,ic);
    menu.push_front(i);
    }
    f.close();
}
 
 
void showlist(list<item> g)
{   int i=1;
    list<item>::iterator it;
    cout<<endl;
    for (it = g.begin(); it != g.end(); ++it){
         cout<<i<<":";
         it->display();
         i++;}
}


bool searchMenu(list<item> g,int n){
    
    list<item>::iterator it;
    bool b=g.empty();
    bool ans=false;
    if(!(b)){
    for (it = g.begin(); it != g.end(); ++it){
        
         if(it->itemCode==n)
         {  
             ans = true;
            
             }
         }
         
         return ans;}
    else
    return false;

}
class Customer
{
    public:
    string RefNo =" ";
    string Phone_num=" ";
    int group_size=0;
    list<item> order;
    list<item> ready;
    Time arrival;
    Time ordered;
    Time left;
    int table;



};

class MainQueue
 {  
     public:
     Customer c;
     Time getTable;
     int table_assigned;

 };

 queue<MainQueue> mainq;

class Table_Queue
 {
     public:
     Customer c;
     Time getEmpty=Time();//what is this for
     Table_Queue(Customer e, Time t)
     {
         c=e;
         getEmpty=t;
     }


 };

class Table
{
    public:
    int size;
    Time Waiting_Time=Time();
    queue<Table_Queue> q;
    Table(int s)
    {
        size =s;
    }
};

vector<Table> tables;

void swap(Table &x, Table &y) 
{ 
    Table temp = x; 
    x = y; 
    y = temp; 
} 
  
void selectionSort(vector<Table> &arr, int n) 
{ 
    int i, j, min; 
  
    for (i = 0; i < n-1; i++) 
    { 
        min = i; 
        for (j = i+1; j < n; j++) 
        if (arr[j].size < arr[min].size) 
            min = j; 
        swap(arr[min], arr[i]); 
    } 
} 


void read_input()
{

    fstream f;
    f.open("input.txt", ios::in );
    if(!f)
    {
        cout<<"File Not Found";
        return ;
    }
    int num, size;
    f>>num; 
    no_of_tables=num;
    f>>num; 
    no_of_servers=num;
    f>>num; 
    queqe_size=num; 
    int i=0;
    while (!f.eof()) 
    {   f>>num; 
        f>>size;
        int j=0;
        while(i<no_of_tables&&j<num)
        {
            tables.push_back(Table(size));
            i++;
            j++;
        }
    }
    selectionSort(tables,no_of_tables);
    
    f.close();
}

class Server_Queue
{
    public:
    Customer c;
    item i;
    Time food_prep=Time();
    Server_Queue(Customer t,item e, Time l)
    {
        c=t;
        i=e;
        food_prep=l;
    }

};

class Server
{
    public:
    queue<Server_Queue> q;
    Time Waiting_Time=Time();
};

vector<Server> servers;

list<int> findAllTables(int size)
{
    list<int> lis;
    int i=0;
    while(size>=tables[i].size&&i<no_of_tables)
    {
        if(size==tables[i].size)
        lis.push_back(i);
        i++;
        
    }
    
return lis;

}

void assignWaitingTime(Table t)
{   if(!t.q.empty())
    t.Waiting_Time=((t.q).back()).getEmpty;
}

void assignWaitingTime(Server s)
{   if(!s.q.empty())
    s.Waiting_Time=((s.q).back()).food_prep;
}

void assignServer(Customer c)
{
    list<item> g= c.order;
    list<item>::iterator it;
    Time total(0,0,0);
    for (it = g.begin(); it != g.end(); ++it)
         {
             int min=0;
             for(int i=0 ; i<no_of_servers;i++)
            {
                    if(servers[i].q.empty())
                    {
                        //servers[i].q.push(Server_Queue(c,*it,c.ordered+it->prep_time));
                        total=total+it->prep_time;
                        break;
                    }
                    else
                    {
                        if(servers[min].Waiting_Time > servers[i].Waiting_Time)
                         min=i;
                    }
                    
            } 
            servers[min].q.push(Server_Queue(c,*it,it->prep_time+servers[min].Waiting_Time));   
            total= total+ it->prep_time+servers[min].Waiting_Time -Time();
         }
         tables[c.table].q.back().getEmpty=c.ordered+total; //assign table empty Time;
  
}

int determineTable(list<int> g)
{

    list<int>::iterator it;
    int min= *(g.begin());
    bool temp=true;
    for(it = g.begin(); it != g.end(); ++it)
         {
             if((tables[*it].q).empty())
             return *it;
             else if(!(tables[*it].Waiting_Time==Time(-1)))
             {
                 
                 if(tables[min].Waiting_Time > tables[*it].Waiting_Time)
                min=*it;
                temp=false;
             }
           
         }
         if(temp!=true)
         return min;
         else 
         return -1;
  
}

/* void assignTable(Customer c)
{//insert last element
MainQueue m;
//mainq.back().table_assigned=c.table;
m.table_assigned=c.table;

    m.getTable=tables[c.table].Waiting_Time;
    mainq.push(m); //push m into mainqueue after updating m
    tables[c.table].q.push(Table_Queue(c,Time(-1)));

} */

MainQueue assignTable(Customer c)
{//insert last element
MainQueue m;
//mainq.back().table_assigned=c.table;
m.c=c;
m.table_assigned=c.table;

    m.getTable=tables[c.table].Waiting_Time;
    //mainq.push(m); //push m into mainqueue after updating m
    tables[c.table].q.push(Table_Queue(c,Time(-1)));
    return m;
}

void serverDeque(Server s)
{   if(s.q.empty())
        {return;}
    while(!(s.q.empty())&&(s.q.front().food_prep<Time()))
     {
         s.q.front().c.ready.push_back(s.q.front().i);
         (s.q).pop();
         
     } 
    
}

void tableDeque(Table t)
{   if(t.q.empty())
        {return;}
    while(!(t.q.empty())&&t.q.front().getEmpty<Time())
      {(t.q).pop();}
    
}

void mainDeque()
{   if((mainq.empty()))
    {return;}
    while(!(mainq.empty())&&mainq.front().getTable<Time())
      mainq.pop();
    
}


void write_customer(Customer c)
{
    ofstream fout;
    fout.open("Customer.bin", ios::out|ios::app|ios::binary);
    if(!fout) {
      cout << "Cannot open file!" << endl;
   }
    fout.write((char *) &c, sizeof(Customer));
    fout.close();
    if(!fout.good()) 
      cout << "Error occurred at writing time!" << endl;
    
}
Customer c1;
list<Customer> loc;//list of customers
void displayBill(Customer c){
    int total=0;
     list<item> g= c.order;
    list<item>::iterator it;
    
    for (it = g.begin(); it != g.end(); ++it)
         {total+=it->cost;}
        cout<<"your total bill inclusive of taxes is"<<total;

}
void take_order()
{// Customer c;
  list<item> ord;
  item o;
    int ans=0,num=0;
 // ord=c1.order;
  //cout<<endl<<"Enter your phone number";
 // cin>>c.Phone_num;
  //cout<<endl<<"Enter your group size";
  //cin>>c.group_size;
  //c.arrival=;
  cout<<"Enter 1 to order now";
  cin>>ans;
  while(ans == 1){
     cout<<"Enter the 3 digit code corresponding to the dishes you wish to order";
     cin>>num;
     if(searchMenu(menu,num))
     {   list<item>::iterator it;
         bool b=menu.empty();
         if(!(b)){
            for (it = menu.begin(); it != menu.end(); ++it){
                if(it->itemCode==num)
                    {  o=*it;
                        ord.push_back(o) ;
            
                    }
                }
                }        
      cout<<" Dish with code number "<<num <<"is added to your order";
      cout<<endl<<"Enter 1 to order another dish or 0 to finalize your order";
      cin>>ans;
    }
  else
  {
  cout<<"You entered invalid code";
  cout<<endl<<"Enter 1 to continue order or 0 to finalize order";
  cin>>ans;
   }
  //c.ordered=;
  //c1.order=ord;
 }
   showlist(ord);
   displayBill(c1);
   mainq.back().c.order=ord;

  //loc.push_back(c1);
}
void informCustomer(Time t,int n){
    cout<<"The waiting time for a group of "<<n<<" is "<<t;

}
void view_menu(){
    read_menu();
    showlist(menu);
    take_order();
    assignServer(mainq.back().c);
}

bool askCustomer(){
    bool b1;
    int n1;
    cout<<endl<<"Please enter 1 for joining the queue and 0 to exit the queue";
    cin>>n1;
    while ((n1!=0)&(n1!=1))
    {
        cout<<"Incorrect choice entered.Please enter again";
        cin>>n1;

    }
    if(n1==1){
        return true;
    }
    else{
        return false;
    }
}
int takeBasicDetails(){
    regex p("[0-9]{10}");
  //list<item> ord;
  //item o;
    //int ans=0,num=0;
  //ord=c.order;
  cout<<endl<<"Enter your phone number";
  cin>>c1.Phone_num;
  bool b=false;
  b=regex_match(c1.Phone_num,p);
  while(!(b)){
      cout<<"Please enter correct 10 digit mobile number";
       cin>>c1.Phone_num;
         b=regex_match(c1.Phone_num,p);
  }
 //check entered mobile number
  
  cout<<"Enter your group size";
  cin>>c1.group_size;
  //c.arrival=;
  c1.RefNo=generateRefNo();
  return c1.group_size;
}
Time findWaitingTime(int capacity){
    Time  waitingTime=Time();
    list<int> options=findAllTables(capacity);
    int table_no=determineTable(options);
    c1.table=table_no;
    if(table_no!=-1){
    
         waitingTime=tables[table_no].Waiting_Time;
         //cout<<"in  findWaitingTime";
    }
    else{
         waitingTime=Time(-1);
         //cout<<"in  findWaitingTime";
    }
    return waitingTime;
}
MainQueue m;
void update(){
    int i=0;
    Table t=Table(0);
    Server s;
    for(i=0;i<no_of_tables;i++){
         t=tables[i];
    assignWaitingTime(t);}
    for(i=0;i<no_of_servers;i++){
        s=servers[i];
    assignWaitingTime(s);}
     mainDeque();
    for(i=0;i<no_of_tables;i++){
         t=tables[i];
   
    tableDeque(t);}
    for(i=0;i<no_of_servers;i++){
        s=servers[i];
    
    serverDeque(s);}

}
int main()
{   int n=0;

    read_input();
    for(int i=0;i<no_of_tables;i++)
     {
        cout<<tables[i].size<<" ";
    }
    tables.shrink_to_fit() ;
    update();
    while (mainq.size()<queqe_size)
    {   //update all queues 
        update();
        Time t1=Time(-1);
        n=takeBasicDetails();//takes i/p of customer phone number and group size and return grup size
         update();
        Time t=findWaitingTime(n);
        cout<<t;//depending on capacity ,it finds and returns the waiting time
        if(!(t==t1)&&(n>0))
        {
            informCustomer(t,n);
            //inform customer of waiting time
            bool b=askCustomer();//ask if user wants to join queue
            if(b)
            {   m=assignTable(c1);
               // m.c=c1;
                //m.getTable=tables[c1.table].Waiting_Time;
            // add customer to mainq
                mainq.push(m);
                //cout<<endl<<mainq.front().table_assigned;
                view_menu();
                
            }
            else
            {
                cout<<"We are sorry to see you go."<<"Hope you'll visit us again soon!";
            }
        }
        else
        {
        cout<<"Currently we cannot seat you!Sorry for inconvenience";
        //
        }
        //take customer phone number

      //  list<item> l=mainq.front().c.order;
        //showlist(l);

    }
    if (mainq.size()>=queqe_size)
    {cout<<"Currently we are at full capacity and are no longer taking customers.Sorry for inconvenience"; }
    
}
